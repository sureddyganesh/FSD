package com.stackroute.muzixmanager.service;

import com.stackroute.muzixmanager.domain.Muzix;
import com.stackroute.muzixmanager.domain.User;
import com.stackroute.muzixmanager.exception.MuzixAlreadyExistsException;
import com.stackroute.muzixmanager.exception.MuzixNotFoundException;

import java.util.List;

public interface MuzixService {

    User saveUser(User user) throws Exception;

    User bookmarkMuzix(Muzix muzix, String userName) throws MuzixAlreadyExistsException;

    User deleteMuzixFromBookmarkList(String id, String userName) throws MuzixNotFoundException;

    List<Muzix> getAllMuzixs(String userName) throws Exception;
}
