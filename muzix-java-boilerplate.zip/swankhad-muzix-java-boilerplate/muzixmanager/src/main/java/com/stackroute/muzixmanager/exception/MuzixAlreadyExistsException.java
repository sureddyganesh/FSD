package com.stackroute.muzixmanager.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.CONFLICT, reason = "Muzix already exists in Bookmarks")
public class MuzixAlreadyExistsException extends Exception {
}
