package com.stackroute.muzixmanager.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document
public class User {

    @Id
    private String userName;
    private List<Muzix> muzixsList;

    public User() { }

    public User(String userName, List<Muzix> muzixsList) {
        this.userName = userName;
        this.muzixsList = muzixsList;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public List<Muzix> getMuzixsList() {
        return muzixsList;
    }

    public void setMuzixsList(List<Muzix> muzixsList) {
        this.muzixsList =muzixsList;
    }

    @Override
    public String toString() {
        return "User{" +
                "userName='" + userName + '\'' +
                ", muzixsList=" + muzixsList +
                '}';
    }
}
