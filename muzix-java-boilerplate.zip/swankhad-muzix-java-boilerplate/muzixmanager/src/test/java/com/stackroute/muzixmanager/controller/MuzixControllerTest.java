package com.stackroute.muzixmanager.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.muzixmanager.domain.Muzix;
import com.stackroute.muzixmanager.domain.Image;
import com.stackroute.muzixmanager.domain.User;
import com.stackroute.muzixmanager.exception.MuzixAlreadyExistsException;
import com.stackroute.muzixmanager.service.MuzixService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;


@RunWith(SpringRunner.class)
@WebMvcTest(MuzixController.class)
public class MuzixControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MuzixService muzixService;

    private User user;
    private Image image;
    private Muzix muzix;
    private List<Muzix> muzixList;

    @Before
    public void setUp() {
        muzixList = new ArrayList<>();

        image = new Image("test image1 url", "20", "20", "30");
        muzix = new Muzix("test1id", "muzix url1", "title of test1 muzix", image);
        muzixList.add(muzix);

        image = new Image("test image2 url", "30", "20", "50");
        muzix = new Muzix("test2id", "muzix url2", "title of test2 muzix", image);
        muzixList.add(muzix);

        user = new User("jenny", muzixList);
    }

    @After
    public void tearDown() {
        image = null;
        muzix = null;
        muzixList = null;
        user = null;
    }

    @Test
        public void testSaveMuzixSuccess() throws MuzixAlreadyExistsException, Exception {
        when(muzixService.bookmarkMuzix(any(),eq(user.getUserName()))).thenReturn(user);
        mockMvc.perform(post("/api/muzixservice/user/{userName}/muzix", user.getUserName())
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonToString(muzix)))
                .andExpect(status().isCreated())
                .andDo(print());
        verify(muzixService, times(1)).bookmarkMuzix(any(), eq(user.getUserName()));
    }

    @Test
    public void testSaveMuzixFailure() throws Exception {
        when(muzixService.bookmarkMuzix(any(), eq(user.getUserName()))).thenThrow(MuzixAlreadyExistsException.class);
        mockMvc.perform(post("/api/muzixservice/user/{userName}/muzix", user.getUserName())
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonToString(muzix)))
                .andExpect(status().isConflict())
                .andDo(print());
        verify(muzixService, times(1)).bookmarkMuzix(any(), eq(user.getUserName()));
    }

    @Test
    public void testDeleteMuzix() throws Exception {
        when(muzixService.deleteMuzixFromBookmarkList(muzix.getId(), user.getUserName())).thenReturn(user);
        System.out.println("Muzix Id: "+user.getMuzixsList().get(1).getId());
        mockMvc.perform(delete("/api/muzixservice/user/{userName}/{id}", user.getUserName(), "test2id")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonToString(muzix)))
                .andExpect(status().isOk())
                .andDo(print());
        verify(muzixService,times(1)).deleteMuzixFromBookmarkList(muzix.getId(), user.getUserName());
    }

    @Test
    public void getAllMuzixs() throws Exception {
        when(muzixService.getAllMuzixs(user.getUserName())).thenReturn(muzixList);
        mockMvc.perform(get("/api/muzixservice/user/{userName}/muzixs", user.getUserName())
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonToString(muzix)))
                .andExpect(status().isOk())
                .andDo(print());
        verify(muzixService,times(1)).getAllMuzixs(user.getUserName());
    }

    private static String jsonToString(final Object ob) throws JsonProcessingException {
        String result;
        try {
            ObjectMapper mapper = new ObjectMapper();
            String jsonContent = mapper.writeValueAsString(ob);
            result = jsonContent;
        } catch(JsonProcessingException j) {
            result = "JSON processing error";
        }

        return result;
    }

}
