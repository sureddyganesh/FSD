package com.stackroute.muzixmanager.service;

import com.stackroute.muzixmanager.domain.Muzix;
import com.stackroute.muzixmanager.domain.Image;
import com.stackroute.muzixmanager.domain.User;
import com.stackroute.muzixmanager.exception.MuzixAlreadyExistsException;
import com.stackroute.muzixmanager.exception.MuzixNotFoundException;
import com.stackroute.muzixmanager.repository.MuzixManagerRepository;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;

public class MuzixServiceTest {

    @Mock
    private MuzixManagerRepository muzixManagerRepository;
    private User user;
    private Muzix muzix;
    private Image image;
    private List<Muzix> muzixList = null;
    private Optional optional;

    @InjectMocks
    private MuzixServiceImpl muzixService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        image = new Image("test image url", "20", "20", "30");
        muzix = new Muzix("muzix test id", "muzix url", "title of test muzix", image);

        muzixList = new ArrayList<>();
        muzixList.add(muzix);

        user = new User("joe", muzixList);

        optional = Optional.of(user);
    }

    @After
    public void tearDown() {
        image = null;
        muzix = null;
        muzixList = null;
        user = null;
    }

    @Test
    public void testSaveMuzix() throws MuzixAlreadyExistsException {
        when(muzixManagerRepository.insert(user)).thenReturn(user);

        User fetchUser = muzixService.bookmarkMuzix(muzix, user.getUserName());
        Muzix fetchMuzix = fetchUser.getMuzixsList().get(0);

        Assert.assertEquals(muzix, fetchMuzix);
        verify(muzixManagerRepository,times(1)).insert(fetchUser);
        verify(muzixManagerRepository,times(1)).findByUserName(user.getUserName());

    }

    @Test
    public void testDeleteMuzix() throws MuzixNotFoundException {
        when(muzixManagerRepository.findByUserName(user.getUserName())).thenReturn(user);

        User fetchUser = muzixService.deleteMuzixFromBookmarkList(muzix.getId(), user.getUserName());

        Assert.assertEquals(user.getUserName(), fetchUser.getUserName());
        Assert.assertEquals(0, fetchUser.getMuzixsList().size());
        verify(muzixManagerRepository,times(1)).findByUserName(user.getUserName());
    }

    @Test
    public void testGetAllMuzixs() throws Exception {
        when(muzixManagerRepository.findByUserName(user.getUserName())).thenReturn(user);

        List<Muzix> fetchList = muzixService.getAllMuzixs(user.getUserName());
        Assert.assertEquals(muzixList, fetchList);

        verify(muzixManagerRepository, times(1)).findByUserName(user.getUserName());
    }

}
