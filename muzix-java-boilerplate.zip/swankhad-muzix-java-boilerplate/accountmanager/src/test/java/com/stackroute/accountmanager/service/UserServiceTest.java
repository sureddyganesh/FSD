package com.stackroute.accountmanager.service;

import com.stackroute.accountmanager.domain.User;
import com.stackroute.accountmanager.exception.UserAlreadyExistsException;
import com.stackroute.accountmanager.exception.UserNotFoundException;
import com.stackroute.accountmanager.repository.UserRepository;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

public class UserServiceTest {

    @Mock
    private UserRepository userRepository;
    private User user;

    @InjectMocks
    private UserServiceImpl userService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        user = new User();
        user.setUserName("Joe");
        user.setPassword("test123");
    }

    @After
    public void tearDown() {
        user = null;
    }

    @Test
    public void testRegisterUser() throws UserAlreadyExistsException {
        Mockito.when(userRepository.save(user)).thenReturn(user);
        User userObj = userService.registerUser(user);

        Assert.assertEquals(user, userObj);
        verify(userRepository,times(1)).save(user);
    }

    @Test
    public void testFindByUserNameAndPassword() throws UserNotFoundException {
        Mockito.when(userRepository.findByUserNameAndPassword(user.getUserName(), user.getPassword())).thenReturn(user);
        User userObj = userService.findByUserNameAndPassword(user.getUserName(), user.getPassword());

        Assert.assertEquals(user.getUserName(), userObj.getUserName());
        verify(userRepository, times(1)).findByUserNameAndPassword(user.getUserName(), user.getPassword());
    }
}
