package com.stackroute.muzixrecommendersystem.service;

import com.stackroute.muzixrecommendersystem.domain.Muzix;
import com.stackroute.muzixrecommendersystem.domain.RecommendedMuzix;
import com.stackroute.muzixrecommendersystem.repository.RecommenderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RecommenderServiceImpl implements RecommenderService {

    private RecommenderRepository recommenderRepository;

    @Autowired
    public RecommenderServiceImpl(RecommenderRepository recommenderRepository) {
        this.recommenderRepository = recommenderRepository;
    }

    @Override
    public boolean saveRecommenderMuzix(RecommendedMuzix recommendedMuzix) {
        RecommendedMuzix fetchRecObj = null;
        boolean status = false;
        try {
           
            fetchRecObj = recommenderRepository.findByRecomMuzixid(recommendedMuzix.getMuzix().getId());
            if (fetchRecObj != null) {
                int counter = fetchRecObj.getNumberOfUsers() + 1;
                recommendedMuzix.setNumberOfUsers(counter);
            } else {
                recommendedMuzix.setNumberOfUsers(1);
            }

            recommenderRepository.save(recommendedMuzix);
            status = true;
        } catch (Exception e) {
            e.printStackTrace();;
        }
             return status;
    }



    @Override
    public List<RecommendedMuzix> getAllRecommendedMuzixs() {
        return recommenderRepository.findAll();
    }
}
