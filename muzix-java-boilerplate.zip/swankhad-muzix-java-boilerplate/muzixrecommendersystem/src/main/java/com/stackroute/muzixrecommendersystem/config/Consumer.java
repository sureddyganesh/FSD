package com.stackroute.muzixrecommendersystem.config;

import com.stackroute.muzixrecommendersystem.domain.Muzix;
import com.stackroute.muzixrecommendersystem.domain.Image;
import com.stackroute.muzixrecommendersystem.domain.RecommendedMuzix;
import com.stackroute.muzixrecommendersystem.service.RecommenderServiceImpl;
import com.stackroute.rabbitmq.domain.UserDto;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Consumer {

    @Autowired
    private RecommenderServiceImpl recommenderService;

    @RabbitListener(queues = "muzixs_queue")
    public void getBookmarkedMuzixFromRabbitMq(UserDto userDto) {

        RecommendedMuzix recommendedMuzix = new RecommendedMuzix();
        RecommendedMuzix.setMuzix(new Muzix());
        RecommendedMuzix.getMuzix().setImage(new Image());

        RecommendedMuzix.setRecomMuzixid(userDto.getMuzix().getId());
        RecommendedMuzix.getMuzix().setId(userDto.getMuzix().getId());
        RecommendedMuzix.getMuzix().setTitle(userDto.getMuzix().getTitle());
        RecommendedMuzix.getMuzix().setUrl(userDto.getMuzix().getUrl());

        RecommendedMuzix.getMuzix().getImage().setImageUrl(userDto.getMuzix().getImage().getImageUrl());
        RecommendedMuzix.getMuzix().getImage().setHeight(userDto.getMuzix().getImage().getHeight());
        RecommendedMuzix.getMuzix().getImage().setWidth(userDto.getMuzix().getImage().getWidth());
        RecommendedMuzix.getMuzix().getImage().setSize(userDto.getMuzix().getImage().getSize());

        recommenderService.saveRecommenderMuzix(RecommendedMuzix);

    }
}
