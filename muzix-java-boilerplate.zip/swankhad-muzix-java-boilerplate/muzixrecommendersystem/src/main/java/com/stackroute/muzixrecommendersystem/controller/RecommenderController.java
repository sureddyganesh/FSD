package com.stackroute.muzixrecommendersystem.controller;

import com.stackroute.muzixrecommendersystem.domain.RecommendedMuzix;
import com.stackroute.muzixrecommendersystem.service.RecommenderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/recommenderservice")
public class RecommenderController {

    private RecommenderService recommenderService;
    private ResponseEntity responseEntity;

    public RecommenderController() {

    }

    @Autowired
    public RecommenderController(RecommenderService recommenderService) {
        this.recommenderService = recommenderService;
    }

    //This method is used only for testing from Postman
    @PostMapping("/save")
    public ResponseEntity saveRecommendMuzix(@RequestBody RecommendedMuzix recommendedMuzix) {
        try {
            recommenderService.saveRecommenderMuzix(recommendedMuzix);
            responseEntity = new ResponseEntity(recommendedMuzix, HttpStatus.CREATED);
        } catch (Exception e) {
            responseEntity = new ResponseEntity("Error while saving recommended muzix", HttpStatus.INTERNAL_SERVER_ERROR);
        }
            return responseEntity;
    }

    @GetMapping("/recomMuzixs")
    public ResponseEntity getAllRecommendedMuzixs() {
        try {
            responseEntity = new ResponseEntity(recommenderService.getAllRecommendedMuzixs(), HttpStatus.OK);
        } catch (Exception e) {
            e.printStackTrace();
            responseEntity = new ResponseEntity("Erro while fetching recommended Muzix list", HttpStatus.INTERNAL_SERVER_ERROR);
        }
            return responseEntity;
    }
}
