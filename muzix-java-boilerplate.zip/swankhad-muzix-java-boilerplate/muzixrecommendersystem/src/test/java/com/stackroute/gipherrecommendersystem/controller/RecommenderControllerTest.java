package com.stackroute.muzixrecommendersystem.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.muzixrecommendersystem.domain.Muzix;
import com.stackroute.muzixrecommendersystem.domain.Image;
import com.stackroute.muzixrecommendersystem.domain.RecommendedMuzix;
import com.stackroute.muzixrecommendersystem.service.RecommenderService;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

@RunWith(SpringRunner.class)
@WebMvcTest(RecommenderController.class)
public class RecommenderControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private RecommenderService recommenderService;

    private RecommendedMuzix recommendedMuzix;
    private Muzix muzix;
    private Image image;
    private List<RecommendedMuzix> recommendedMuzixList;

    @Before
    public void setUp() {
        recommendedMuzixList = new ArrayList<>();
        image = new Image("image url1", "20", "20", "normal");
        muzix = new Muzix("muzix1", "test muzix url", "Test muzix title", image);
        recommendedMuzix = new RecommendedMuzix("muzix1", muzix, 1);
        recommendedMuzixList.add(recommendedMuzix);
    }

    @After
    public void tearDown() {
        image = null;
        muzix = null;
        recommendedMuzix = null;
        recommendedMuzixList = null;
    }

    @Test
    public void testSaveMuzixSuccess() throws Exception {
        when(recommenderService.saveRecommenderMuzix(recommendedMuzix)).thenReturn(true);
        mockMvc.perform(post("/api/recommenderservice/save")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonToString(recommendedMuzix)))
                .andExpect(status().isCreated())
                .andDo(print());
        verify(recommenderService, times(1)).saveRecommenderMuzix(any());
    }

    @Test
    public void getAllRecommendedMuzixs() throws Exception {
        when(recommenderService.getAllRecommendedMuzixs()).thenReturn(recommendedMuzixList);
        mockMvc.perform(get("/api/recommenderservice/recomMuzixs")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonToString(recommendedMuzix)))
                .andExpect(status().isOk())
                .andDo(print());
        verify(recommenderService,times(1)).getAllRecommendedMuzixs();
        Assert.assertEquals(recommendedMuzixList.size(), 1);
    }

    private static String jsonToString(final Object ob) throws JsonProcessingException {
        String result;
        try {
            ObjectMapper mapper = new ObjectMapper();
            String jsonContent = mapper.writeValueAsString(ob);
            result = jsonContent;
        } catch(JsonProcessingException j) {
            result = "JSON processing error";
        }

        return result;
    }
}
