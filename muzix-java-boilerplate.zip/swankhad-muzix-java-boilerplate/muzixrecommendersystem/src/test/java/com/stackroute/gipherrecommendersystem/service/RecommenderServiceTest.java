package com.stackroute.muzixrecommendersystem.service;

import com.stackroute.muzixrecommendersystem.domain.Muzix;
import com.stackroute.muzixrecommendersystem.domain.Image;
import com.stackroute.muzixrecommendersystem.domain.RecommendedMuzix;
import com.stackroute.muzixrecommendersystem.repository.RecommenderRepository;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;

import static org.mockito.Mockito.*;

public class RecommenderServiceTest {

    @Mock
    private RecommenderRepository recommenderRepository;
    private RecommendedMuzix recommendedMuzix;
    private Muzix muzix;
    private Image image;
    private List<RecommendedMuzix> recommendedMuzixList;

    @InjectMocks
    private RecommenderServiceImpl recommenderService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        image = new Image("image url1", "20", "20", "normal");
        muzix = new Muzix("muzix1", "test muzix url", "Test muzix title", image);
        recommendedMuzix = new RecommendedMuzix("Muzix1", muzix, 1);
    }

    @After
    public void tearDown() {
        image = null;
        muzix = null;
        recommendedMuzix = null;
        recommendedMuzixList = null;
    }

    @Test
    public void testSaveRecommendedMuzix() {
        when(recommenderRepository.insert(recommendedMuzix)).thenReturn(recommendedMuzix);

        boolean status = recommenderService.saveRecommenderMuzix(recommendedMuzix);

        Assert.assertEquals(status, true);
        verify(recommenderRepository,times(1)).findByRecomMuzixid(recommendedMuzix.getRecomMuzixid());
    }
}
