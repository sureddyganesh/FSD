package com.stackroute.orchestrationService.service;

import com.stackroute.orchestrationService.domain.User;
import com.stackroute.orchestrationService.exception.UserAlreadyExistsException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class OrchestrationServiceImpl implements OrchestrationService {

    @Autowired
    RestTemplate restTemplate;

    String registerUrl = "http://accountmanagerservice/api/accountmanager/register";
    String saveUrl = "http://muzixmanagerservice/api/muzixservice/save";

    @Override
    public User registerUser(User user) throws UserAlreadyExistsException {
        User userResponse = null;
        try {
            userResponse = restTemplate.postForObject(registerUrl, user, User.class);
            restTemplate.postForObject(saveUrl,user,User.class);
        } catch (Exception e) {
            throw new UserAlreadyExistsException();
        }
        return userResponse;
    }
}
