import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AuthenticationService } from './authentication.service';

const testUserData={
  userName:"smruti",
  password:"test"
}
const registerUrl = "http://localhost:8087/orchestrationservice/api/v1/user";
const loginUrl = "http://localhost:8087/accountmanagerservice/api/accountmanager/login";

describe('AuthenticationService', () => {
  let authService: AuthenticationService;
  let httpTestingController: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AuthenticationService]
    });
    authService = TestBed.get(AuthenticationService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  it('should be created', () => {
    expect(authService).toBeTruthy();
  });

  it('registerUser() should fetch response from Http call', () => {
      authService.registerUser(testUserData).subscribe(response => {
        expect(response.body).toBe(testUserData);
      });
      const httpMockRequest = httpTestingController.expectOne(registerUrl);
      expect(httpMockRequest.request.method).toBe('POST');
      expect(httpMockRequest.request.url).toEqual(registerUrl);
  }); 

  it('loginUser() should fetch response from Http call', () => {
    authService.loginUser(testUserData).subscribe(response => {
      expect(response.body).toBe(testUserData);
    });
    const httpMockRequest = httpTestingController.expectOne(loginUrl);
    expect(httpMockRequest.request.method).toBe('POST');
    expect(httpMockRequest.request.url).toEqual(loginUrl);
  }); 

});
