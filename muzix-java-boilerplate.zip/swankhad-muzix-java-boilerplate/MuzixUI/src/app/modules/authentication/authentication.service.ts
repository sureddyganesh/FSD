import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
export const USER_NAME = "userName";
export const TOKEN_NAME = "jwt_token";

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  // private springAccountMgrEndPoint: string;
  // private springMuzixMgrEndPoint: string;
  private springRegAndSaveEndPoint: string;
  private springLoginEndPoint: string;

  constructor(private httpClient: HttpClient) { 
    //this.springAccountMgrEndPoint = "http://localhost:8084/api/accountmanager/";
    //this.springMuzixMgrEndPoint = "http://localhost:8085/api/muzixservice/";
    this.springRegAndSaveEndPoint = "http://localhost:8087/orchestrationservice/api/v1/user";
    this.springLoginEndPoint = "http://localhost:8087/accountmanagerservice/api/accountmanager/login";
  }

  registerUser(newUser) {
    console.log("in register");
    const url = this.springRegAndSaveEndPoint;
    return this.httpClient.post(url, newUser, { observe: "response"});
  }

  // saveUser(newUser) {
  //   const url = this.springMuzixMgrEndPoint + "save";
  //   return this.httpClient.post(url, newUser);
  // }

  loginUser(newUser) {
    const url = this.springLoginEndPoint;
    // sessionStorage.setItem(USER_NAME, newUser.userName);
    return this.httpClient.post(url, newUser, { observe: "response"});
  }

  getToken() {
    return localStorage.getItem(TOKEN_NAME);
  }

  isTokenExpired() {
    if(localStorage.getItem(TOKEN_NAME)) {
      return true;
    } else {
      return false;
    }
  }

  logout() {
    sessionStorage.removeItem(USER_NAME);
    sessionStorage.clear();

    localStorage.removeItem(TOKEN_NAME);
    localStorage.clear();
  }
}
