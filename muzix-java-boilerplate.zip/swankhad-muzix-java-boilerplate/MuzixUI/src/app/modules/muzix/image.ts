export class Image {
    url: string;
    width: string;
    height: string;
    size: string;
}