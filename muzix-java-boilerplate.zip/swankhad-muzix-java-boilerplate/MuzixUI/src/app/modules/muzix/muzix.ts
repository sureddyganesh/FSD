import { Image } from 'src/app/modules/muzix/image';

export class Muzix {
    id: string;
    url: string;
    title: string;
    image: Image;
}