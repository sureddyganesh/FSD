import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Muzix } from './muzix';
import { Recommendedmuzix } from './recommendedmuzix';
import { USER_NAME } from '../authentication/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class MuzixService {
  thirdpartyApi: string;
  apiKey: string;
  recommendedMuzixsApi: string;
  springEndPoint: string;
  userName: string;

  constructor(private httpClient: HttpClient) { 
    this.thirdpartyApi = "https://api.napster.com/v2.0/playlists?apikey=";
    this.apiKey = "ZTk2YjY4MjMtMDAzYy00MTg4LWE2MjYtZDIzNjJmMmM0YTdm";
    this.recommendedMuzixsApi = "http://localhost:8087/recommenderservice/api/recommenderservice/recomMuzixs";
    this.springEndPoint = "http://localhost:8087/muzixmanagerservice/api/muzixservice/user/";
  }

  getMuzixDetailsFromApi():Observable<any> {
    const url = `${this.thirdpartyApi}${this.apiKey}`;
    
  //  const options = {
  //    headers: new HttpHeaders({
  //    'Content-Type': 'application/json',
  //    'Access-Control-Allow-Credentials': 'true'
  //    })
      
  //   // };
    return this.httpClient.get(url);
  }

  bookmarkMuzix(muzix: Muzix) {
    console.log("inside bookmarkMuzix in muzix service");
    this.userName = sessionStorage.getItem(USER_NAME);
    const url = this.springEndPoint + this.userName + "/muzix";
    console.log("url in boomark service: ", url);
    return this.httpClient.post(url, muzix, { observe: "response" });
  }

  getAllBookmarkMuzixs(): Observable<Muzix[]> {
    this.userName = sessionStorage.getItem(USER_NAME);
    const url = this.springEndPoint + this.userName + "/muzixs";
    return this.httpClient.get<Muzix[]>(url);
  }

  deleteMuzix(muzix: Muzix) {
    this.userName = sessionStorage.getItem(USER_NAME);
    const url = this.springEndPoint + this.userName + "/" + `${muzix.id}`;
    return this.httpClient.delete(url, { responseType: "text" });
  }

  getAllRecommendedMuzixs(): Observable<any> {
    const url = this.recommendedMuzixsApi;
    return this.httpClient.get(url);
  }
}
