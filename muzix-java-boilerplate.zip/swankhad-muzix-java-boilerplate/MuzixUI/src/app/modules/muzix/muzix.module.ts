import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CardContainerComponent } from './components/card-container/card-container.component';
import { CardComponent } from './components/card/card.component';
import { HeaderComponent } from './components/header/header.component';
import { AppRoutingModule } from '../../app-routing.module';
import { BookmarkComponent } from './components/bookmark/bookmark.component';
import { FooterComponent } from './components/footer/footer.component';
import { FormsModule } from '@angular/forms';
import { AngularmaterialModule } from '../angularmaterial/angularmaterial.module';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { InterceptorService } from 'src/app/modules/muzix/interceptor.service';
import { MuzixService } from './muzix.service';
import { RecommendationsComponent } from './components/recommendations/recommendations.component';
import { RecommendationCardComponent } from './components/recommendation-card/recommendation-card.component'


@NgModule({
  declarations: [
    CardContainerComponent, 
    CardComponent, HeaderComponent, BookmarkComponent, FooterComponent, RecommendationsComponent, RecommendationCardComponent
  ],
  imports: [
    CommonModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    FormsModule,
    AngularmaterialModule
  ],
  exports: [
    CardContainerComponent,
    HeaderComponent,
    AppRoutingModule,
    FooterComponent,
    RecommendationCardComponent
  ],
  providers: [
    MuzixService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true
    }
  ]
  
  
  
})
export class MuzixModule { }
