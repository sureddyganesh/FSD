import { TestBed } from '@angular/core/testing';
import { Muzix } from './muzix';
import { MuzixService } from './muzix.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('MuzixService', () => {
  let muzixservice: MuzixService;
  let httpTestingController: HttpTestingController;
  let muzix = new Muzix();
  
  muzix = {
    id: "testmuzixId",
    url: "test muzix url",
    title: "test muzix title",
    image: {
      url: "image test url",
      width: "image width",
      height: "image height",
      size: "image size"
    }
  };
  
  const springEndPoint = "http://localhost:8087/muzixmanagerservice/api/muzixservice/user/";
  
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [MuzixService]
    });
    muzixservice = TestBed.get(MuzixService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  it('should be created', () => {
    expect(muzixservice).toBeTruthy();
    expect(httpTestingController).toBeTruthy();
  });



});
