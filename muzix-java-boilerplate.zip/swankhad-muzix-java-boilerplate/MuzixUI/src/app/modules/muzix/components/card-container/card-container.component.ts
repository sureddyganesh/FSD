import { Component, OnInit } from '@angular/core';
import { MuzixService } from 'src/app/modules/muzix/muzix.service';
import { Muzix } from 'src/app/modules/muzix/muzix';
import { Image } from 'src/app/modules/muzix/image';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBar } from "@angular/material";

@Component({
  selector: 'app-card-container',
  templateUrl: './card-container.component.html',
  styleUrls: ['./card-container.component.css']
})
export class CardContainerComponent implements OnInit {

  muzixArray: Muzix[];
  muzixObj: Muzix;
  imageObj: Image;
  muzixTitle: string;
  searchMuzixs: Array<Muzix>;
  statusCode: number;
  errorStatus: string;
  
  constructor(
    private muzixService: MuzixService,
    private routes: ActivatedRoute,
    private matSnackbar: MatSnackBar) { 
    this.muzixArray = [];
  }

  ngOnInit() {
    this.muzixService.getMuzixDetailsFromApi().subscribe(muzixArray => {
        console.log(muzixArray);
        this.muzixArray = [];
        const data = muzixArray['data'];

        data.forEach(targetData => {
          this.muzixObj = new Muzix();
          this.imageObj = new Image();
          this.imageObj = targetData['images']['preview_muzix'];
          this.muzixObj = targetData;
          this.muzixObj.image = this.imageObj;
          

          this.muzixArray.push(this.muzixObj);
          this.searchmuzixs = this.muzixArray;
        });
    });
  }

  onKey(event: any) {
    this.muzixTitle = event.target.value;
    const result = this.searchMuzixs.filter(muzix => {
      return muzix.title.match(this.muzixTitle);
    });
    this.muzixArray = result;
  }

  bookmarkMuzix(muzix) {
    this.muzixService.bookmarkMuzix(muzix).subscribe(data => {
      console.log(data);

      this.statusCode = data.status;
      if(this.statusCode === 201) {
        console.log("Added successfully");
        this.matSnackbar.open("Bookmarked Muzix successfully!", " ", {
          duration: 2000
        });
      } 
    },
    error => {
      this.errorStatus = `${error.status}`;
      const errorMsg = `${error.error.message}`;
      this.statusCode = parseInt(this.errorStatus, 10);
      
      if(this.statusCode === 409) {
        this.matSnackbar.open(errorMsg, " ", {
          duration: 2000
        });
        this.statusCode = 0;
      }
      else if(this.statusCode === 500) {
        console.log("Status 500");
        this.matSnackbar.open("Login to bookamark Muzix", " ", {
          duration: 2000
        });
      }
    });
  }

}
