import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MuzixService } from 'src/app/modules/muzix/muzix.service';
import { Muzix } from 'src/app/modules/muzix/muzix';
import { Image } from 'src/app/modules/muzix/image';
import { Recommendedmuzix } from 'src/app/modules/muzix/recommendedmuzix';

@Component({
  selector: 'app-recommendation-card',
  templateUrl: './recommendation-card.component.html',
  styleUrls: ['./recommendation-card.component.css']
})
export class RecommendationCardComponent implements OnInit {

  @Input()
  recommendedmuzix: Recommendedmuzix;

 constructor() { }

 

  ngOnInit() {
  }    

}
