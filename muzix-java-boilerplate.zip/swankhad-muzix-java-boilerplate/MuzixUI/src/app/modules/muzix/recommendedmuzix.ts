import { Muzix } from './muzix';

export class Recommendedmuzix {
    recomMuzixid: string;
    muzix: Muzix;
    numberOfUsers: number;
}