export MYSQL_URL=jdbc:mysql://localhost:3306/UserDB
export MYSQL_USER=root
export MYSQL_PASSWORD=root