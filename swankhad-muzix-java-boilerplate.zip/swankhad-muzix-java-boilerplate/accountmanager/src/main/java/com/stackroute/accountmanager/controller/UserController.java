package com.stackroute.accountmanager.controller;

import com.stackroute.accountmanager.domain.User;
import com.stackroute.accountmanager.exception.UserAlreadyExistsException;
import com.stackroute.accountmanager.exception.UserNotFoundException;
import com.stackroute.accountmanager.service.SecurityTokenGenerator;
import com.stackroute.accountmanager.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@CrossOrigin("*")
@RequestMapping("api/accountmanager")
public class UserController {

    private UserService userService;
    private SecurityTokenGenerator securityTokenGenerator;
    private ResponseEntity responseEntity;

    @Autowired
    public UserController(UserService userService, SecurityTokenGenerator securityTokenGenerator) {
        this.userService = userService;
        this.securityTokenGenerator = securityTokenGenerator;
    }

    @PostMapping("/register")
    public ResponseEntity registerUser(@RequestBody User user) throws UserAlreadyExistsException {
        try {
            userService.registerUser(user);
            responseEntity = new ResponseEntity(user, HttpStatus.CREATED);
        } catch (UserAlreadyExistsException u) {
            throw new UserAlreadyExistsException();
        } catch (Exception e) {
           responseEntity = new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
            return responseEntity;
    }

    @PostMapping("/login")
    public ResponseEntity loginUser(@RequestBody User user) throws UserNotFoundException {
        Map<String, String> map =null;
        try {
            User userObj = userService.findByUserNameAndPassword(user.getUserName(), user.getPassword());

            if(userObj!= null) {
                map = securityTokenGenerator.generateToken(user);
                responseEntity = new ResponseEntity(map, HttpStatus.OK);
            }
        } catch (UserNotFoundException u) {
            throw new UserNotFoundException();
        } catch (Exception e) {
            responseEntity = new ResponseEntity("Error while authenticating User. Try again!", HttpStatus.INTERNAL_SERVER_ERROR);
        }
            return responseEntity;
    }
}
