package com.stackroute.accountmanager.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.accountmanager.domain.User;
import com.stackroute.accountmanager.exception.UserAlreadyExistsException;
import com.stackroute.accountmanager.exception.UserNotFoundException;
import com.stackroute.accountmanager.service.SecurityTokenGenerator;
import com.stackroute.accountmanager.service.UserService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest
public class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserService userService;

    @MockBean
    private SecurityTokenGenerator securityTokenGenerator;

    @InjectMocks
    private UserController userController;

    private User user;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
        user = new User();
        user.setUserName("Joe");
        user.setPassword("test123");
    }

    @Test
    public void testRegisterUser() throws UserAlreadyExistsException, Exception {
        when(userService.registerUser(any())).thenReturn(user);
        mockMvc.perform(post("/api/accountmanager/register")
               .contentType(MediaType.APPLICATION_JSON).content(jsonToString(user)))
               .andExpect(status().isCreated()).andDo(print());
        verify(userService, times(1)).registerUser(any());
    }

    @Test
    public void testLoginUser() throws UserNotFoundException, Exception {
        when(userService.registerUser(user)).thenReturn(user);
        when(userService.findByUserNameAndPassword(user.getUserName(), user.getPassword())).thenReturn(user);
        mockMvc.perform(post("/api/accountmanager/login")
               .contentType(MediaType.APPLICATION_JSON).content(jsonToString(user)))
               .andExpect(status().isOk()).andDo(print());
        verify(userService, times(1)).findByUserNameAndPassword(user.getUserName(), user.getPassword());
    }

    private String jsonToString(User user) {
        String result;
        try {
            ObjectMapper mapper = new ObjectMapper();
            String jsonContent = mapper.writeValueAsString(user);
            result = jsonContent;
        } catch(JsonProcessingException j) {
            result = "JSON processing error";
        }

        return result;
    }
}
