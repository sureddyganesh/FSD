package com.stackroute.muzixrecommendersystem.repository;

import com.netflix.discovery.converters.Auto;
import com.stackroute.muzixrecommendersystem.domain.Muzix;
import com.stackroute.muzixrecommendersystem.domain.Image;
import com.stackroute.muzixrecommendersystem.domain.RecommendedMuzix;
import com.stackroute.muzixrecommendersystem.service.RecommenderService;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@DataMongoTest
public class RecommenderRepositoryTest {

    @Autowired
    private RecommenderRepository recommenderRepository;
    private RecommendedMuzix recommendedMuzix;
    private Muzix muzix;
    private Image image;
    private List<RecommendedMuzix> recommendedMuzixList;

    @Before
    public void setUp() {
        image = new Image("image url1", "20", "20", "normal");
        muzix = new Muzix("muzix1", "test muzix url", "Test muzix title", image);
        recommendedMuzix = new RecommendedMuzix("muzix1", muzix, 1);
    }

    @After
    public void tearDown() {
        image = null;
        muzix = null;
        recommendedMuzix = null;
        recommendedMuzixList = null;
        recommenderRepository.deleteAll();
    }

    @Test
    public void testSaveRecommendedMuzix() {
        recommenderRepository.insert(recommendedMuzix);

        List<RecommendedMuzix> fetchList = recommenderRepository.findAll();
        RecommendedMuzix fetchRecommMuzix = fetchList.get(0);

        Assert.assertEquals(fetchRecommMuzix.getMuzix().getTitle(), muzix.getTitle());
    }

    @Test
    public void testGetRecommendedMuzixList() {
        recommenderRepository.insert(recommendedMuzix);

        List<RecommendedMuzix> fetchList = recommenderRepository.findAll();

        Assert.assertEquals(fetchList.size(), 1);
    }
}
