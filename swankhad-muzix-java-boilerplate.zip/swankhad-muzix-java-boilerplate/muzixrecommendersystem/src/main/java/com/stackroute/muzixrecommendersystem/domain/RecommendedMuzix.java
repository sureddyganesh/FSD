package com.stackroute.muzixrecommendersystem.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class RecommendedMuzix {

    @Id
    private String recommuzixid;
    private Muzix muzix;
    private int numberOfUsers;

    public RecommendedMuzix() {
    }

    public RecommendedMuzix(Muzix muzix) {
       this.muzix = muzix;
    }

    public RecommendedMuzix(String recomMuzixid, Muzix muzix, int numberOfUsers) {
        this.recomMuzixid = recomMuzixid;
        this.muzix = muzix;
        this.numberOfUsers = numberOfUsers;
    }

    public String getRecomMuzixid() {
        return recomMuzixid;
    }

    public void setRecomMuzixid(String recomMuzixid) {
        this.recomMuzixid = recomMuzixid;
    }

    public Muzix getMuzix() {
        return muzix;
    }

    public void setMuzix(Muzix muzix) {
        this.muzix = muzix;
    }

    public int getNumberOfUsers() {
        return numberOfUsers;
    }

    public void setNumberOfUsers(int numberOfUsers) {
        this.numberOfUsers = numberOfUsers;
    }
}
