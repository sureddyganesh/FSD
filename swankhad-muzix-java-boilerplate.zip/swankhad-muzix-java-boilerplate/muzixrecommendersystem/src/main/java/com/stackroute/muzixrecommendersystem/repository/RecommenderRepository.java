package com.stackroute.muzixrecommendersystem.repository;

import com.stackroute.muzixrecommendersystem.domain.RecommendedMuzix;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface RecommenderRepository extends MongoRepository<RecommendedMuzix, String> {

    RecommendedMuzix findByRecomMuzixid(String id);
}
