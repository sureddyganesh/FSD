package com.stackroute.muzixrecommendersystem.service;

import com.stackroute.muzixrecommendersystem.domain.Muzix;
import com.stackroute.muzixrecommendersystem.domain.RecommendedMuzix;

import java.util.List;

public interface RecommenderService {

    boolean saveRecommenderMuzix(RecommendedMuzix recommendedMuzix);

    List<RecommendedMuzix> getAllRecommendedMuzixs();

}
