package com.stackroute.muzixrecommendersystem.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Image {

    @JsonProperty("url")
    private String imageUrl;
    private String width;
    private String height;
    private String size;

    public Image() {
    }

    public Image(String imageUrl, String width, String height, String size) {
        this.imageUrl = imageUrl;
        this.width = width;
        this.height = height;
        this.size = size;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }
}
