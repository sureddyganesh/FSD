import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CardContainerComponent } from 'src/app/modules/muzix/components/card-container/card-container.component';
import { BookmarkComponent } from 'src/app/modules/muzix/components/bookmark/bookmark.component';
import { RegisterComponent } from './modules/authentication/components/register/register.component'
import { LoginComponent } from './modules/authentication/components/login/login.component';
import { AuthGuardService } from './modules/muzix/auth-guard.service';
import { RecommendationsComponent } from './modules/muzix/components/recommendations/recommendations.component';
import { RecommendationCardComponent } from 'src/app/modules/muzix/components/recommendation-card/recommendation-card.component';

const routes: Routes = [
  {
    path: "",
    component: LoginComponent
  },

  {
    path: "login",
    component: LoginComponent
  },

  {
    path: "register",
    component: RegisterComponent
  },

  {
    path: "Home",
    component: CardContainerComponent
  },

  {
    path:"Bookmark",
    component: BookmarkComponent,
    canActivate: [AuthGuardService]
  },

  {
    path:"Recommendations",
    component: RecommendationsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
