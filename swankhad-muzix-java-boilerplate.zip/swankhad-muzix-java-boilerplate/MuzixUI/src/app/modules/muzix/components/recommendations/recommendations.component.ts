import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MuzixService } from 'src/app/modules/muzix/muzix.service';
import { Muzix } from 'src/app/modules/muzix/muzix';
import { MatSnackBar } from '@angular/material';
import { Recommendedmuzix } from 'src/app/modules/muzix/recommendedmuzix';
@Component({
  selector: 'app-recommendations',
  templateUrl: './recommendations.component.html',
  styleUrls: ['./recommendations.component.css']
})
export class RecommendationsComponent implements OnInit {

  @Output()
  recomBookmarkMuzix = new EventEmitter();

  muzixs: Muzix[];

  constructor(
    private muzixService: MuzixService,
    private snackbar: MatSnackBar
  ) { }

  ngOnInit() {
    console.log("inside recom component ngOnInit")
    const noRecommendationsMsg = "No recommendations available now";
    this.muzixService.getAllRecommendedMuzixs().subscribe(data => {
      console.log("recomm data", data);
      this.muzixs = data;

      if(data == null || data.length === 0) {
        this.snackbar.open(noRecommendationsMsg, " ", {
          duration: 2000
        })
      }
    });
  }

  recommBookmarkButtonClick(muzix) {
    //console.log("inside recomm card component for bookmark", muzix);
    this.recomBookmarkMuzix.emit(muzix);
  }

  bookmarkmuzix(muzix) {
    //console.log("Inider recom comp bookmark");
    this.muzixService.bookmarkMuzix(muzix).subscribe(data => {
     // console.log(data);

      // this.statusCode = data.status;
      // if(this.statusCode === 201) {
      //   console.log("Added successfully");
      //   this.matSnackbar.open("Bookmarked muzix successfully!", " ", {
      //     duration: 2000
      //   });
      // } 
   // },
    // error => {
    //   this.errorStatus = `${error.status}`;
    //   const errorMsg = `${error.error.message}`;
    //   this.statusCode = parseInt(this.errorStatus, 10);
      
    //   if(this.statusCode === 409) {
    //     this.matSnackbar.open(errorMsg, " ", {
    //       duration: 2000
    //     });
    //     this.statusCode = 0;
    //   }
    //   else if(this.statusCode === 500) {
    //     console.log("Status 500");
    //     this.matSnackbar.open("Login to bookamark muzix", " ", {
    //       duration: 2000
    //     });
    //   }
     });
  }
}
