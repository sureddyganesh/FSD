import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Muzix } from 'src/app/modules/muzix/muzix';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {

  @Input()
  muzix: Muzix;

  @Input()
  bookmarkFlag: boolean;

  @Output()
  bookmarkMuzix = new EventEmitter();

  @Output()
  deleteMuzix = new EventEmitter();

  constructor() { }

  bookmarkButtonClick(muzix) {
   this.bookmarkMuzix.emit(muzix);
  }

  deleteButtonClick(muzix) {
    this.deleteMuzix.emit(muzix);
  }

  ngOnInit() {
  }

}
