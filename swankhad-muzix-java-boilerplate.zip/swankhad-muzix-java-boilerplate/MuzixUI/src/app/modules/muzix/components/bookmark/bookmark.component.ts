import { Component, OnInit } from '@angular/core';
import { MuzixService } from 'src/app/modules/muzix/muzix.service';
import { Muzix } from 'src/app/modules/muzix/muzix';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-bookmark',
  templateUrl: './bookmark.component.html',
  styleUrls: ['./bookmark.component.css']
})
export class BookmarkComponent implements OnInit {

  muzixs: Array<Muzix>;
  bookmarkFlag = true;

  constructor(
    private muzixService: MuzixService,
    private snackbar: MatSnackBar
  ) { }

  ngOnInit() {
    const noBookmarksMsg = "No Bookmarks Available ";
    this.muzixService.getAllBookmarkMuzixs().subscribe(data => {
      this.muzixs = data;
      console.log(this.muzixs);
      /**if(data.length === 0) { **/
       if(data == null || data.length === 0) {
        this.snackbar.open(noBookmarksMsg, " ", {
          duration: 2000
        })
      }
    });
  }

  deleteMuzix(muzix) {
    this.muzixService.deleteMuzix(muzix).subscribe(data => {
      const index = this.muzixs.indexOf(muzix);
      this.muzixs.splice(index, 1);
      this.snackbar.open("Successfully deleted", " ", {
        duration: 2000
      });
    });
      return this.muzixs;
  }

}
