import { AppPage } from './app.po';
import { browser, by, element} from "protractor";

describe('workspace-project App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display title of application', () => {
    page.navigateTo();
    expect(browser.getTitle()).toEqual('MuzixUI');
  });

  it('should be redirected to login route', () => {
    browser.driver.manage().window().maximize();
    browser.element(by.css('.register-user')).click();
    expect(browser.getCurrentUrl()).toContain('/register');
    browser.driver.sleep(2000);
  });

  it('should be able to register user', () => {
    browser.element(by.id('userName')).sendKeys('sujitha');
    browser.driver.sleep(2000);
    browser.element(by.id('password')).sendKeys('suji');
    browser.driver.sleep(2000);
    browser.element(by.css('.register-user')).click();
    browser.driver.sleep(3000);
  });

  it('should be able to login user', () => {
    browser.element(by.id('userName')).sendKeys('sujitha');
    browser.driver.sleep(2000);
    browser.element(by.id('password')).sendKeys('suji');
    browser.driver.sleep(2000);
    browser.element(by.css('.login-user')).click();
    browser.driver.sleep(2000);
  });

  it('should be able to bookmark muzix', () => {
    browser.driver.manage().window().maximize();
    browser.driver.sleep(2000);
    const muzix = element.all(by.css('.example-card'));
    browser.sleep(2000);
    browser.element(by.css('.bookmarkButton')).click();
    browser.sleep(2000);
  });

  it('should be able to get all bookmarks muzixs', () => {
    browser.driver.sleep(2000);
    browser.element(by.id('bookmarkId')).click();
    expect(browser.getCurrentUrl()).toContain("/Bookmark");
    browser.driver.sleep(2000);
  });

  it('should be able to delete muzix in the bookmarks', () => {
    browser.driver.sleep(2000);
    const muzixs = element.all(by.css("example-card"));
    browser.driver.sleep(2000);
    browser.element(by.css('.deletebutton')).click();
    browser.driver.sleep(2000);
  });

  it('should be able to go to muzix home', () => {
    browser.driver.sleep(2000);
    browser.element(by.css('.mat-button-home')).click();
    expect(browser.getCurrentUrl()).toContain("Home");
    browser.driver.sleep(2000);
  });

  it('should be able to go to recommendations home', () => {
    browser.driver.sleep(2000);
    browser.element(by.id('recommendId')).click();
    expect(browser.getCurrentUrl()).toContain("Recommendations");
    browser.driver.sleep(2000);
  });

  it('should be able to logout from application', () => {
    browser.driver.sleep(2000);
    browser.element(by.id('logoutId')).click();
    browser.driver.sleep(2000);
  });
  
});
