package com.stackroute.muzixmanager.repository;

import com.stackroute.muzixmanager.domain.Muzix;
import com.stackroute.muzixmanager.domain.Image;
import com.stackroute.muzixmanager.domain.User;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RunWith(SpringRunner.class)
@DataMongoTest
public class MuzixRepositoryTest {

    @Autowired
    private MuzixManagerRepository muzixManagerRepository;
    private User user;
    private Muzix muzix;
    private Image image;
    private List<Muzix> muzixList;

    @Before
    public void setUp() {
        image = new Image("test image url", "20", "20", "30");
        muzix = new Muzix("muzix test id", "muzix url", "title of test muzix", image);
        muzixList = new ArrayList<>();
        muzixList.add(muzix);
        user = new User("joe", muzixList);
    }

    @After
    public void tearDown() {
        image = null;
        muzix = null;
        muzixList=null;
        user = null;
        muzixManagerRepository.deleteAll();
    }

    @Test
    public void testSaveMuzix() {
        muzixManagerRepository.insert(user);

        User fetchUser = muzixManagerRepository.findByUserName(user.getUserName());
        Muzix fetchMuzix = fetchUser.getMuzixsList().get(0);

        Assert.assertEquals(fetchMuzix.getTitle(), muzix.getTitle());
    }

    @Test
    public void testGetAllMuzixs() {
        muzixManagerRepository.insert(user);

        User fetchUser = muzixManagerRepository.findByUserName(user.getUserName());

        List<Muzix> muzixList = fetchUser.getMuzixsList();
        Assert.assertEquals(1, muzixList.size());
        Assert.assertEquals("title of test muzix", muzixList.get(0).getTitle());
    }

    @Test
    public void testDeleteMuzix() {
        muzixManagerRepository.insert(user);

        User fetchUser = muzixManagerRepository.findByUserName(user.getUserName());

        List<Muzix> fetchMuzixList = fetchUser.getMuzixsList();

        for(int i=0; i<fetchMuzixList.size(); i++) {
            Muzix fetchMuzix = fetchMuzixList.get(i);
            if(muzix.getId().equals(fetchMuzix.getId())) {
                fetchMuzixList.remove(i);
                fetchUser.setMuzixsList(fetchMuzixList);
                muzixManagerRepository.save(fetchUser);
            }
         }

        fetchUser = muzixManagerRepository.findByUserName(user.getUserName());
        fetchMuzixList = fetchUser.getMuzixsList();

        Assert.assertEquals(0, fetchMuzixList.size());
    }

}
