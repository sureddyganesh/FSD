package com.stackroute.muzixmanager.repository;

import com.stackroute.muzixmanager.domain.User;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface MuzixManagerRepository extends MongoRepository<User, String> {

    User findByUserName(String userName);
}
