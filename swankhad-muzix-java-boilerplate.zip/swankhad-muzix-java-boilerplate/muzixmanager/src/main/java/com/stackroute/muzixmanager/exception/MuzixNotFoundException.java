package com.stackroute.muzixmanager.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.NOT_FOUND, reason = "Muzix not found")
public class MuzixNotFoundException extends Exception {
}
