package com.stackroute.muzixmanager.domain;

import org.springframework.data.annotation.Id;

public class Muzix {

    @Id
    private String id;
    private String url;
    private String title;
    private Image image;

    public Muzix() { }

    public Muzix(String id, String url, String title, Image image) {
        this.id = id;
        this.url = url;
        this.title = title;
        this.image = image;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "Muzix{" +
                "id='" + id + '\'' +
                ", url='" + url + '\'' +
                ", title='" + title + '\'' +
                ", image=" + image +
                '}';
    }
}
