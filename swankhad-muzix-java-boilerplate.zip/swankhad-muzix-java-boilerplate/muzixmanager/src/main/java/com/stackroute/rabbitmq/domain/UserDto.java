package com.stackroute.rabbitmq.domain;

public class UserDto {

    private String userName;
    private MuzixDto muzix;

    public UserDto() {
    }

    public UserDto(String userName, MuzixDto muzix) {
        this.userName = userName;
        this.muzix = muzix;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public MuzixDto getMuzix() {
        return muzix;
    }

    public void setMuzix(MuzixDto muzix) {
        this.muzix = muzix;
    }
}
