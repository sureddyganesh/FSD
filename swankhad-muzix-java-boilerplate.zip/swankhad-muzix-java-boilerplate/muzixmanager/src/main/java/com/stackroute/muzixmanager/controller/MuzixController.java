package com.stackroute.muzixmanager.controller;

import com.stackroute.muzixmanager.domain.Muzix;
import com.stackroute.muzixmanager.domain.User;
import com.stackroute.muzixmanager.exception.MuzixAlreadyExistsException;
import com.stackroute.muzixmanager.exception.MuzixNotFoundException;
import com.stackroute.muzixmanager.service.MuzixService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/muzixservice")
public class MuzixController {

    private MuzixService muzixService;
    private ResponseEntity responseEntity;

    public MuzixController() { }

    @Autowired
    public MuzixController(MuzixService muzixService) {
        this.muzixService = muzixService;
    }

    @PostMapping("/save")
    public ResponseEntity saveUser(@RequestBody User user) {
        try {
            muzixService.saveUser(user);
            responseEntity = new ResponseEntity(user, HttpStatus.CREATED);
        } catch (Exception e) {
            responseEntity = new ResponseEntity("Error while saving user.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
            return responseEntity;
    }

    @PostMapping("/user/{userName}/muzix")
    public ResponseEntity bookmarkMuzix(@RequestBody Muzix muzix, @PathVariable("userName") String userName) throws MuzixAlreadyExistsException {
        try {
            User user = muzixrService.bookmarkMuzix(muzix, userName);
            responseEntity = new ResponseEntity(muzix), HttpStatus.CREATED);
        } catch (MuzixAlreadyExistsException g) {
            throw new MuzixAlreadyExistsException();
        } catch (Exception e) {
            e.printStackTrace();
            responseEntity = new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseEntity;
    }

    @DeleteMapping("/user/{userName}/{id}")
    public ResponseEntity deleteBookmark(@PathVariable("id") String id, @PathVariable("userName") String userName) throws MuzixNotFoundException {
        try {
            User user = muzixService.deleteMuzixFromBookmarkList(id, userName);
            responseEntity = new ResponseEntity(user, HttpStatus.OK);
        } catch (MuzixNotFoundException g) {
            throw new MuzixNotFoundException();
        } catch (Exception e) {
            responseEntity = new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
            return responseEntity;
    }

    @GetMapping("/user/{userName}/muzixs")
    public ResponseEntity getAllMuzixs(@PathVariable("userName") String userName) {
        try {
            responseEntity = new ResponseEntity(muzixService.getAllMuzixs(userName), HttpStatus.OK);
        } catch(Exception e) {
            responseEntity = new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
            return responseEntity;
    }
}
