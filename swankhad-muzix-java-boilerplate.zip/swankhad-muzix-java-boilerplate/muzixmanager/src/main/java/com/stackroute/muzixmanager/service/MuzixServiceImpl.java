package com.stackroute.muzixmanager.service;

import com.stackroute.muzixmanager.config.Producer;
import com.stackroute.muzixmanager.domain.Muzix;
import com.stackroute.muzixmanager.domain.User;
import com.stackroute.muzixmanager.exception.MuzixAlreadyExistsException;
import com.stackroute.muzixmanager.exception.MuzixNotFoundException;
import com.stackroute.muzixmanager.repository.MuzixManagerRepository;
import com.stackroute.rabbitmq.domain.MuzixDto;
import com.stackroute.rabbitmq.domain.ImageDto;
import com.stackroute.rabbitmq.domain.UserDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MuzixServiceImpl implements MuzixService {

    private MuzixManagerRepository muzixManagerRepository;
    private Producer producer;

    @Autowired
    public MuzixServiceImpl(MuzixManagerRepository muzixManagerRepository, Producer producer) {
        this.muzixManagerRepository = muzixManagerRepository;
        this.producer = producer;
    }

    @Override
    public User saveUser(User user) throws Exception {
        return muzixManagerRepository.save(user);
    }

    @Override
    public User bookmarkMuzix(Muzix muzix, String userName) throws MuzixAlreadyExistsException {
        User fetchUser = muzixManagerRepository.findByUserName(userName);
        UserDto userDto = new UserDto();
        MuzixDto muzixDto = new MuzixDto();
        muzixDto.setImage(new ImageDto());

        userDto.setUserName(userName);
        List<Muzix> fetchMuzixs = fetchUser.getMuzixsList();

        if(fetchMuzixs!= null) {
            for(Muzix muzixObj : fetchMuzixs) {
                if(muzixObj.getId().equals(muzix.getId())) {
                    throw new MuzixAlreadyExistsException();
                }
            }

            fetchMuzixs.add(muzix);
            fetchUser.setMuzixsList(fetchMuzixs);

            muzixDto.setId(muzix.getId());
            muzixDto.setTitle(muzix.getTitle());
            muzixDto.setUrl(muzix.getUrl());

            muzixDto.getImage().setImageUrl(muzix.getImage().getImageUrl());
            muzixDto.getImage().setHeight(muzix.getImage().getHeight());
            muzixDto.getImage().setWidth(muzix.getImage().getWidth());
            muzixDto.getImage().setSize(muzix.getImage().getSize());

            userDto.setMuzix(muzixDto);

            muzixManagerRepository.save(fetchUser);
            producer.sendMessageToRabbitMq(userDto);
        } else {
            fetchMuzixs = new ArrayList<>();
            fetchMuzixs.add(muzix);
            fetchUser.setMuzixsList(fetchMuzixs);

            muzixDto.setId(muzix.getId());
            muzixDto.setTitle(muzix.getTitle());
            muzixDto.setUrl(muzix.getUrl());

            muzixDto.getImage().setImageUrl(muzix.getImage().getImageUrl());
            muzixDto.getImage().setHeight(muzix.getImage().getHeight());
            muzixDto.getImage().setWidth(muzix.getImage().getWidth());
            muzixDto.getImage().setSize(muzix.getImage().getSize());
            userDto.setMuzix(muzixDto);

            muzixManagerRepository.save(fetchUser);
            producer.sendMessageToRabbitMq(userDto);
        }
            return fetchUser;
    }

    @Override
    public User deleteMuzixFromBookmarkList(String id, String userName) throws MuzixNotFoundException {
        User fetchUser = muzixManagerRepository.findByUserName(userName);
        List<Muzix> fetchMuzixs = fetchUser.getMuzixsList();

        if(fetchMuzixs!= null && fetchMuzixs.size() > 0) {
            for(int i=0; i<fetchMuzixs.size(); i++) {
                if(id.equals(fetchMuzixs.get(i).getId())) {
                    fetchMuzixs.remove(i);

                    fetchUser.setMuzixsList(fetchMuzixs);
                    muzixManagerRepository.save(fetchUser);
                    break;
                }
            }
        } else {
            throw new MuzixNotFoundException();
        }
            return fetchUser;
    }

    @Override
    public List<Muzix> getAllMuzixs(String userName) throws Exception {
        User fetchUser = muzixManagerRepository.findByUserName(userName);
        return fetchUser.getMuzixsList();
    }
}
